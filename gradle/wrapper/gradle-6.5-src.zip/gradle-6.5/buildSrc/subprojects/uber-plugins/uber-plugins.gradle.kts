dependencies {
    implementation(project(":binaryCompatibility"))
    implementation(project(":buildquality"))
    implementation(project(":cleanup"))
    implementation(project(":configuration"))
    implementation(project(":kotlinDsl"))
    implementation(project(":plugins"))
    implementation(project(":profiling"))
    implementation("org.gradle.kotlin:gradle-kotlin-dsl-conventions:0.5.0")
}
